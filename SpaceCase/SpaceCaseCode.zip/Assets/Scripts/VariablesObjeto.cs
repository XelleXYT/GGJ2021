﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VariablesObjeto : MonoBehaviour
{
    public string tipo;
    public string color1;
    public string color2;
}
